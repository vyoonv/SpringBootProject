package edu.kh.project.email.model.service;

public interface EmailService {

}
