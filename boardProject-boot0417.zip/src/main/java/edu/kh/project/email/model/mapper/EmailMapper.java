package edu.kh.project.email.model.mapper;

import org.apache.ibatis.annotations.Mapper;

@Mapper
public interface EmailMapper {

}
