package edu.kh.project.board.controller;

import org.springframework.stereotype.Controller;

@Controller
public class BoardController {

}
